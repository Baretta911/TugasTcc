export const BASE_URL = "https://be-1061342868557.us-central1.run.app";
